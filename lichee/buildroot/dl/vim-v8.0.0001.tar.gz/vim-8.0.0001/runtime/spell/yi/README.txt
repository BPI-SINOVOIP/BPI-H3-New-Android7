README file for the Yiddish spell file.

The word list was provided by Raphael Finkel.  It is the same one that is used
by uspell.

There also is a romanized (transliterated) word list.  This is used for
latin1.  To use this list when 'encoding' is utf-8 use ":set spelllang=yi-tr".

Copyright Raphael Finkel.  Included with permission in Vim.
