/* 
 * Copyright (c) 2010 Wind River Systems; see
 * guts/COPYRIGHT for information.
 *
 * static void
 * wrap_setgrent(void) {
 *	
 */

	pseudo_grp_open();

/*	return;
 * }
 */
