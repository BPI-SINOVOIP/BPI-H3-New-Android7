/*
 * Copyright (c) 2016 Wind River Systems; see
 * guts/COPYRIGHT for information.
 *
 * int mknodat(int dirfd, const char *path, mode_t mode, dev_t dev)
 *	int rc = -1;
 */

	rc = wrap___xmknodat(_MKNOD_VER, dirfd, path, mode, &dev);

/*	return rc;
 * }
 */
