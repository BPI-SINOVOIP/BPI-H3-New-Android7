/* 
 * Copyright (c) 2010 Wind River Systems; see
 * guts/COPYRIGHT for information.
 *
 * static int
 * wrap_euidaccess(const char *path, int mode) {
 *	int rc = -1;
 */

	rc = wrap_access(path, mode);

/*	return rc;
 * }
 */
