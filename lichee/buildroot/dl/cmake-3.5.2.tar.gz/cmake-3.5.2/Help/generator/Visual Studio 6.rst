Visual Studio 6
---------------

Deprected.  Generates Visual Studio 6 project files.

.. note::
  This generator is deprecated and will be removed
  in a future version of CMake.  It will still be
  possible to build with VS 6 tools using the
  :generator:`NMake Makefiles` generator.
