.. cmake-module:: ../../Modules/FindEXPAT.cmake
