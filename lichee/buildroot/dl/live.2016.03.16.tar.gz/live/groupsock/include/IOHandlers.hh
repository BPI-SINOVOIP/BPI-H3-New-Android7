/**********
This library is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version. (See <http://www.gnu.org/copyleft/lesser.html>.)

This library is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this library; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
**********/
// "mTunnel" multicast access service
// Copyright (c) 1996-2016 Live Networks, Inc.  All rights reserved.
// IO event handlers
// C++ header

#ifndef _IO_HANDLERS_HH
#define _IO_HANDLERS_HH

#ifndef _NET_INTERFACE_HH
#include "NetInterface.hh"
#endif

// Handles incoming data on sockets:
void socketReadHandler(Socket* sock, int mask);

#endif
